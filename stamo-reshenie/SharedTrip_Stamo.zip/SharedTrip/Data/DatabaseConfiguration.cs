﻿namespace SharedTrip.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.;Database=SharedTrip;User Id = sa; Password=SoftUn!2021;";
    }
}