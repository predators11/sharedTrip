﻿namespace SharedTrip.Models
{
    public class UserViewModel
    {
        
    }
}
