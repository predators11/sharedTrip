﻿namespace SharedTrip.Models
{
    public class TripDetailsViewModel : TripViewModel
    {
        public string Id { get; set; }
    }
}
