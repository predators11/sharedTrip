﻿namespace SharedTrip.Models
{
    public class ErrorViewModel
    {
        public string ErrorMessage { get; init; }

        public ErrorViewModel(string message)
        {
            ErrorMessage = message;
        }
    }
}
