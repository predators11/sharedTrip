﻿namespace SharedTrip.Models
{
    public class UserTrip
    {
        
    }
}
